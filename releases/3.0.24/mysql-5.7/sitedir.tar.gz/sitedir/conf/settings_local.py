# Site-specific configuration settings for Review Board
# Definitions of these settings can be found at
# http://docs.djangoproject.com/en/dev/ref/settings/

import os


# Database configuration
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'reviewboard',
        'USER': 'reviewboard',
        'PASSWORD': 'reviewboard',
        'HOST': 'localhost',
    },
}

# Unique secret key. Don't share this with anybody.
SECRET_KEY = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMN'

# Cache backend settings.
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
        'LOCATION': 'localhost:11211',
    },
}

# Extra site information.
SITE_ID = 1
SITE_ROOT = '/'
FORCE_SCRIPT_NAME = ''
DEBUG = False
ALLOWED_HOSTS = ['example.com']
