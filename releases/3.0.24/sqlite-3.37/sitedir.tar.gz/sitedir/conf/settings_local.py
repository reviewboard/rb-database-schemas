# Site-specific configuration settings for Review Board
# Definitions of these settings can be found at
# http://docs.djangoproject.com/en/dev/ref/settings/

# Database configuration
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': '/tmp/sitedir/data/reviewboard.db',
    },
}

# Unique secret key. Don't share this with anybody.
SECRET_KEY = 'dg@78b#v2p)17n(z-rc27@)f&f1%gt&8%^2vg@h4-dfawj2hjx'

# Cache backend settings.
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.memcached.MemcachedCache',
        'LOCATION': 'localhost:11211',
    },
}

# Extra site information.
SITE_ID = 1
SITE_ROOT = '/'
FORCE_SCRIPT_NAME = ''
DEBUG = False
ALLOWED_HOSTS = ['example.com']
